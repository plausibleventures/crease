Box with a hinged lid
=====================

A small box whose lid swings open on a pin made from a piece of 1.75 mm printer filament.

Licence: Same licence as the Crease repository (see its LICENSE file)
Made with Crease 0.0.1 on 2026-10-09.

What's inside
- guide/       step-by-step assembly guide (open the .html in a browser)
- bom/         shopping list: what to print, buy and make
- models/      STL files to slice on any printer
- source/      the editable OpenSCAD design (open the whole pack in Crease to keep designing)

Parts
- 1× Box (80 × 67.5 × 47 mm), white
- 1× Lid (80 × 72.5 × 7 mm), blue

Check the files: sha256sum -c CHECKSUMS.sha256
