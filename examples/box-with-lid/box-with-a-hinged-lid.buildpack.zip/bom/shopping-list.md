# Shopping list: Box with a hinged lid

"Search on …" links open a store search, not a specific product: check the listing matches the spec (size, standard, material) before buying. "Verified listing" links are product pages that were actually opened, with the date.

| Need | Item | Spec | Suggested pack | Search for | Where |
|---|---|---|---|---|---|
| 1 | 1.75 mm filament, 80 mm long | PLA filament | 1 (cut to length if needed) | 1.75 mm PLA filament | [Search on Amazon](https://www.amazon.com/s?k=1.75%20mm%20PLA%20filament) · [Search on AliExpress](https://www.aliexpress.com/wholesale?SearchText=1.75%20mm%20PLA%20filament) · [Search on Bolt Depot](https://www.boltdepot.com/Search?keywords=1.75%20mm%20PLA%20filament) · [Search on McMaster-Carr](https://www.mcmaster.com/products/1.75-mm-pla-filament/) |

## Tools

- Side cutters or scissors
