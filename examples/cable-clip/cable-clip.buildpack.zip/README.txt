Cable clip
==========

Licence: Same licence as the Crease repository (see its LICENSE file)
Made with Crease 0.0.1 on 2026-10-09.

What's inside
- guide/       step-by-step assembly guide (open the .html in a browser)
- bom/         shopping list: what to print, buy and make
- models/      STL files to slice on any printer
- source/      the editable OpenSCAD design (open the whole pack in Crease to keep designing)

Parts
- 1× clip (36.5 × 10 × 12 mm), white

Check the files: sha256sum -c CHECKSUMS.sha256
