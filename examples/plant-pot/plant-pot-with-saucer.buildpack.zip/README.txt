Plant pot with saucer
=====================

A tapered pot with drainage holes that sits in a matching saucer.

Licence: Same licence as the Crease repository (see its LICENSE file)
Made with Crease 0.0.1 on 2026-10-09.

What's inside
- guide/       step-by-step assembly guide (open the .html in a browser)
- bom/         shopping list: what to print, buy and make
- models/      STL files to slice on any printer
- source/      the editable OpenSCAD design (open the whole pack in Crease to keep designing)

Parts
- 1× Pot (91.2 × 91.2 × 80 mm), white
- 1× Saucer (86 × 86 × 12 mm), white

Check the files: sha256sum -c CHECKSUMS.sha256
