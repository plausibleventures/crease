# Shopping list: Plant pot with saucer

"Search on …" links open a store search, not a specific product: check the listing matches the spec (size, standard, material) before buying. "Verified listing" links are product pages that were actually opened, with the date.

